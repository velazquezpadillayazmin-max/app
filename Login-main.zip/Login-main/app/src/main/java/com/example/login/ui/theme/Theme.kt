package com.example.login.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

@Composable
fun LoginTheme(content: @Composable () -> Unit) {
    // Tema básico para iniciar con Compose
    MaterialTheme(
        colorScheme = lightColorScheme(),
        content = content
    )
}
