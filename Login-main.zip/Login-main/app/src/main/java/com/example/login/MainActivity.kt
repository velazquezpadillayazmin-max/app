package com.example.login

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.tooling.preview.Preview
import com.example.login.data.AuthRepository
import com.example.login.data.LoginResult
import com.example.login.ui.LoginScreen
import com.example.login.ui.WelcomeScreen
import com.example.login.ui.theme.LoginTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginTheme {
                LoginApp()
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun LoginAppPreview() {
    LoginTheme {
        LoginApp()
    }
}

@Composable
private fun LoginApp() {
    // Estados simples para un primer proyecto en Compose
    var username by rememberSaveable { mutableStateOf("emilys") }
    var password by rememberSaveable { mutableStateOf("emilyspass") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var isLoggedIn by remember { mutableStateOf(false) }

    // Repositorio para consumir la API (en un proyecto real usaríamos DI)
    val repository = remember { AuthRepository() }
    val scope = rememberCoroutineScope()

    if (isLoggedIn) {
        WelcomeScreen(
            username = username,
            onLogout = {
                isLoggedIn = false
                errorMessage = null
            }
        )
    } else {
        LoginScreen(
            username = username,
            onUsernameChange = { username = it },
            password = password,
            onPasswordChange = { password = it },
            isLoading = isLoading,
            errorMessage = errorMessage,
            onLoginClick = {
                // Validación básica en el cliente
                if (username.isBlank() || password.isBlank()) {
                    errorMessage = "Completa usuario y contraseña."
                    return@LoginScreen
                }

                errorMessage = null
                isLoading = true

                scope.launch {
                    when (val result = repository.login(username, password)) {
                        is LoginResult.Success -> {
                            isLoggedIn = true
                        }
                        is LoginResult.Error -> {
                            errorMessage = result.message
                        }
                    }
                    isLoading = false
                }
            }
        )
    }
}
