package com.example.login.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

// Resultado simple del login para la UI
sealed class LoginResult {
    data class Success(val token: String) : LoginResult()
    data class Error(val message: String) : LoginResult()
}

class AuthRepository {
    private val api: AuthApi = RetrofitProvider.api

    suspend fun login(username: String, password: String): LoginResult {
        return withContext(Dispatchers.IO) {
            try {
                val response = api.login(LoginRequest(username, password))
                if (response.isSuccessful) {
                    val body = response.body()
                    val token = body?.accessToken ?: body?.token ?: ""
                    LoginResult.Success(token)
                } else {
                    val rawError = response.errorBody()?.string()
                    val message = parseErrorMessage(rawError)
                    LoginResult.Error(message)
                }
            } catch (ex: Exception) {
                LoginResult.Error("No se pudo conectar con la API.")
            }
        }
    }

    // Intenta leer el campo "message" o "error"; si no, devuelve un mensaje genérico
    private fun parseErrorMessage(rawError: String?): String {
        return try {
            if (rawError.isNullOrBlank()) {
                "Credenciales incorrectas."
            } else {
                val json = JSONObject(rawError)
                val message = json.optString("message")
                if (message.isNotBlank()) {
                    message
                } else {
                    json.optString("error", "Credenciales incorrectas.")
                }
            }
        } catch (ex: Exception) {
            "Credenciales incorrectas."
        }
    }
}

// Proveedor simple de Retrofit (para un proyecto real usaríamos inyección de dependencias)
private object RetrofitProvider {
    private val logging = HttpLoggingInterceptor().apply {
        // BASIC es suficiente para ver si la petición funciona sin saturar el Logcat
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(logging)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://dummyjson.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .client(client)
        .build()

    val api: AuthApi = retrofit.create(AuthApi::class.java)
}
