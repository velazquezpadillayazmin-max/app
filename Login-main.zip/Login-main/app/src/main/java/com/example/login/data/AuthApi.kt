package com.example.login.data

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

// Modelos que representan el JSON enviado/recibido
data class LoginRequest(
    val username: String,
    val password: String
)

data class LoginResponse(
    val accessToken: String? = null,
    val token: String? = null
)

// Endpoint de ejemplo: https://dummyjson.com/auth/login
interface AuthApi {
    @Headers("Content-Type: application/json")
    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>
}
